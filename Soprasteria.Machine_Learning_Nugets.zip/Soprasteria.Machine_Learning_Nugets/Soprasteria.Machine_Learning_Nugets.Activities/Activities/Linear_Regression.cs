using System;
using System.Activities;
using System.Threading;
using System.Threading.Tasks;
using System.Data;
using Soprasteria.Machine_Learning_Nugets.Activities.Properties;
using UiPath.Shared.Activities;
using UiPath.Shared.Activities.Localization;
using System.Linq;


namespace Soprasteria.Machine_Learning_Nugets.Activities
{
    [LocalizedDisplayName(nameof(Resources.Linear_Regression_DisplayName))]
    [LocalizedDescription(nameof(Resources.Linear_Regression_Description))]
    public class Linear_Regression : ContinuableAsyncCodeActivity
    {
        #region Properties

        /// <summary>
        /// If set, continue executing the remaining activities even if the current activity has failed.
        /// </summary>
        [LocalizedCategory(nameof(Resources.Common_Category))]
        [LocalizedDisplayName(nameof(Resources.ContinueOnError_DisplayName))]
        [LocalizedDescription(nameof(Resources.ContinueOnError_Description))]
        public override InArgument<bool> ContinueOnError { get; set; }

        [LocalizedCategory(nameof(Resources.Common_Category))]
        [LocalizedDisplayName(nameof(Resources.Timeout_DisplayName))]
        [LocalizedDescription(nameof(Resources.Timeout_Description))]
        public InArgument<int> TimeoutMS { get; set; } = 60000;

        [LocalizedDisplayName(nameof(Resources.Linear_Regression_In_ValueToPredict_DisplayName))]
        [LocalizedDescription(nameof(Resources.Linear_Regression_In_ValueToPredict_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<int> In_ValueToPredict { get; set; }

        [LocalizedDisplayName(nameof(Resources.Linear_Regression_In_Datatable_DisplayName))]
        [LocalizedDescription(nameof(Resources.Linear_Regression_In_Datatable_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<DataTable> In_Datatable { get; set; }

        [LocalizedDisplayName(nameof(Resources.Linear_Regression_In_IndependentVariableColumn_DisplayName))]
        [LocalizedDescription(nameof(Resources.Linear_Regression_In_IndependentVariableColumn_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> In_IndependentVariableColumn { get; set; }

        [LocalizedDisplayName(nameof(Resources.Linear_Regression_In_DependentVariableColumn_DisplayName))]
        [LocalizedDescription(nameof(Resources.Linear_Regression_In_DependentVariableColumn_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> In_DependentVariableColumn { get; set; }

        [LocalizedDisplayName(nameof(Resources.Linear_Regression_Out_PredictedValue_DisplayName))]
        [LocalizedDescription(nameof(Resources.Linear_Regression_Out_PredictedValue_Description))]
        [LocalizedCategory(nameof(Resources.Output_Category))]
        public OutArgument<string> Out_PredictedValue { get; set; }

        #endregion


        #region Constructors

        public Linear_Regression()
        {
        }

        #endregion


        #region Protected Methods

        protected override void CacheMetadata(CodeActivityMetadata metadata)
        {
            if (In_ValueToPredict == null) metadata.AddValidationError(string.Format(Resources.ValidationValue_Error, nameof(In_ValueToPredict)));
            if (In_Datatable == null) metadata.AddValidationError(string.Format(Resources.ValidationValue_Error, nameof(In_Datatable)));
            if (In_IndependentVariableColumn == null) metadata.AddValidationError(string.Format(Resources.ValidationValue_Error, nameof(In_IndependentVariableColumn)));
            if (In_DependentVariableColumn == null) metadata.AddValidationError(string.Format(Resources.ValidationValue_Error, nameof(In_DependentVariableColumn)));

            base.CacheMetadata(metadata);
        }

        protected override async Task<Action<AsyncCodeActivityContext>> ExecuteAsync(AsyncCodeActivityContext context, CancellationToken cancellationToken)
        {
            try
            {
                var timeout = TimeoutMS.Get(context);
                var in_valuetopredict = In_ValueToPredict.Get(context);
                var in_datatable = In_Datatable.Get(context);
                var in_independentvariablecolumn = In_IndependentVariableColumn.Get(context);
                var in_dependentvariablecolumn = In_DependentVariableColumn.Get(context);

                // Set a timeout on the execution
                var task = ExecuteWithTimeout(context, cancellationToken);
                if (await Task.WhenAny(task, Task.Delay(timeout, cancellationToken)) != task) throw new TimeoutException(Resources.Timeout_Error);

                // Outputs
                return (ctx) =>
                {
                    Out_PredictedValue.Set(ctx, task.Result.ToString());
                };
            }
            catch(Exception ex)
            {
                throw new Exception(ex.StackTrace + "Error Message:" + ex.Message);
            }
        }

        //private async Task ExecuteWithTimeout(AsyncCodeActivityContext context, CancellationToken cancellationToken = default)
        //{
        //    ///////////////////////////
        //    // Add execution logic HERE
        //    ///////////////////////////
        //}
        private async Task<double> ExecuteWithTimeout(AsyncCodeActivityContext context, CancellationToken cancellationToken = default)
        {
            ///////////////////////////
            // Add execution logic HERE
            ///////////////////////////
            var xValues = new double[] { };
            var yValues = new double[] { };
            int Predinput = this.In_ValueToPredict.Get((ActivityContext)context);
            string Independentcol = this.In_IndependentVariableColumn.Get((ActivityContext)context);
            string Dependentcol = this.In_DependentVariableColumn.Get((ActivityContext)context);
            DataTable Mastertable = this.In_Datatable.Get((ActivityContext)context);
            double rSquared, intercept, slope;
            //converting datatables to double array
            xValues = Mastertable.AsEnumerable().Select(s => s.Field<double>(Independentcol)).ToArray<double>();
            yValues = Mastertable.AsEnumerable().Select(s => s.Field<double>(Dependentcol)).ToArray<double>();
            //call Liner regression
            LinearRegression(xValues, yValues, out rSquared, out intercept, out slope);

            Console.WriteLine($"R-squared = {rSquared}");
            Console.WriteLine($"Intercept = {intercept}");
            Console.WriteLine($"Slope = {slope}");

            var predictedValue = (slope * Predinput) + intercept;
            Console.WriteLine($"Prediction for {Predinput} : {predictedValue}");
            return predictedValue;
        }

        public static void LinearRegression(double[] xVals, double[] yVals, out double rSquared, out double yIntercept, out double slope)
        {
            try
            {
                if (xVals.Length != yVals.Length)
                {
                    throw new Exception("Input values should be with the same length.");
                }

                double sumOfX = 0;
                double sumOfY = 0;
                double sumOfXSq = 0;
                double sumOfYSq = 0;
                double sumCodeviates = 0;

                for (var i = 0; i < xVals.Length; i++)
                {
                    var x = xVals[i];
                    var y = yVals[i];
                    sumCodeviates += x * y;
                    sumOfX += x;
                    sumOfY += y;
                    sumOfXSq += x * x;
                    sumOfYSq += y * y;
                }

                var count = xVals.Length;
                var ssX = sumOfXSq - ((sumOfX * sumOfX) / count);
                var ssY = sumOfYSq - ((sumOfY * sumOfY) / count);

                var rNumerator = (count * sumCodeviates) - (sumOfX * sumOfY);
                var rDenom = (count * sumOfXSq - (sumOfX * sumOfX)) * (count * sumOfYSq - (sumOfY * sumOfY));
                var sCo = sumCodeviates - ((sumOfX * sumOfY) / count);

                var meanX = sumOfX / count;
                var meanY = sumOfY / count;
                var dblR = rNumerator / Math.Sqrt(rDenom);

                rSquared = dblR * dblR;
                yIntercept = meanY - ((sCo / ssX) * meanX);
                slope = sCo / ssX;
            }
            catch
            {
                throw new NotImplementedException();
            }
        }

    }
    #endregion
}


