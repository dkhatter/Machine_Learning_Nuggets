using System;
using System.Activities;
using System.Threading;
using System.Threading.Tasks;
using System.Data;
using Soprasteria.Machine_Learning_Nugets.Activities.Properties;
using UiPath.Shared.Activities;
using UiPath.Shared.Activities.Localization;
using System.Collections.Generic;
using System.IO;
using System.Linq;


namespace Soprasteria.Machine_Learning_Nugets.Activities
{
    [LocalizedDisplayName(nameof(Resources.K_NEAREST_NEIGHBORS_DisplayName))]
    [LocalizedDescription(nameof(Resources.K_NEAREST_NEIGHBORS_Description))]
    public class K_NEAREST_NEIGHBORS : ContinuableAsyncCodeActivity
    {
        #region Properties

        /// <summary>
        /// If set, continue executing the remaining activities even if the current activity has failed.
        /// </summary>
        [LocalizedCategory(nameof(Resources.Common_Category))]
        [LocalizedDisplayName(nameof(Resources.ContinueOnError_DisplayName))]
        [LocalizedDescription(nameof(Resources.ContinueOnError_Description))]
        public override InArgument<bool> ContinueOnError { get; set; }

        [LocalizedCategory(nameof(Resources.Common_Category))]
        [LocalizedDisplayName(nameof(Resources.Timeout_DisplayName))]
        [LocalizedDescription(nameof(Resources.Timeout_Description))]
        public InArgument<int> TimeoutMS { get; set; } = 60000;

        [LocalizedDisplayName(nameof(Resources.K_NEAREST_NEIGHBORS_In_Training_DataSet_DisplayName))]
        [LocalizedDescription(nameof(Resources.K_NEAREST_NEIGHBORS_In_Training_DataSet_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> In_Training_DataSet { get; set; }

        [LocalizedDisplayName(nameof(Resources.K_NEAREST_NEIGHBORS_In_Test_Dataset_DisplayName))]
        [LocalizedDescription(nameof(Resources.K_NEAREST_NEIGHBORS_In_Test_Dataset_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<string> In_Test_Dataset { get; set; }

        [LocalizedDisplayName(nameof(Resources.K_NEAREST_NEIGHBORS_In_Classification_Cluster_Number_DisplayName))]
        [LocalizedDescription(nameof(Resources.K_NEAREST_NEIGHBORS_In_Classification_Cluster_Number_Description))]
        [LocalizedCategory(nameof(Resources.Input_Category))]
        public InArgument<Int32> In_Classification_Cluster_Number { get; set; }

        [LocalizedDisplayName(nameof(Resources.K_NEAREST_NEIGHBORS_Out_Clasification_Accuracy_DisplayName))]
        [LocalizedDescription(nameof(Resources.K_NEAREST_NEIGHBORS_Out_Clasification_Accuracy_Description))]
        [LocalizedCategory(nameof(Resources.Output_Category))]
        public OutArgument<double> Out_Clasification_Accuracy { get; set; }

        [LocalizedDisplayName(nameof(Resources.K_NEAREST_NEIGHBORS_Out_Clasification_Results_DisplayName))]
        [LocalizedDescription(nameof(Resources.K_NEAREST_NEIGHBORS_Out_Clasification_Results_Description))]
        [LocalizedCategory(nameof(Resources.Output_Category))]
        public OutArgument<DataTable> Out_Clasification_Results { get; set; }

        #endregion


        #region Constructors

        public K_NEAREST_NEIGHBORS()
        {
        }

        #endregion


        #region Protected Methods

        protected override void CacheMetadata(CodeActivityMetadata metadata)
        {
            if (In_Training_DataSet == null) metadata.AddValidationError(string.Format(Resources.ValidationValue_Error, nameof(In_Training_DataSet)));
            if (In_Test_Dataset == null) metadata.AddValidationError(string.Format(Resources.ValidationValue_Error, nameof(In_Test_Dataset)));
            if (In_Classification_Cluster_Number == null) metadata.AddValidationError(string.Format(Resources.ValidationValue_Error, nameof(In_Classification_Cluster_Number)));

            base.CacheMetadata(metadata);
        }

        protected override async Task<Action<AsyncCodeActivityContext>> ExecuteAsync(AsyncCodeActivityContext context, CancellationToken cancellationToken)
        {
            // Inputs
            var timeout = TimeoutMS.Get(context);
            var in_training_dataset = In_Training_DataSet.Get(context);
            var in_test_dataset = In_Test_Dataset.Get(context);
            var in_classification_cluster_number = In_Classification_Cluster_Number.Get(context);

            // Set a timeout on the execution
            var task = ExecuteWithTimeout(context, cancellationToken);
            if (await Task.WhenAny(task, Task.Delay(timeout, cancellationToken)) != task) throw new TimeoutException(Resources.Timeout_Error);
            // Outputs
            return (ctx) => {
                Out_Clasification_Accuracy.Set(ctx, task.Result.Item2);
                Out_Clasification_Results.Set(ctx, task.Result.Item1);
            };
            
        }

        private async Task<Tuple<DataTable, double>> ExecuteWithTimeout(AsyncCodeActivityContext context, CancellationToken cancellationToken = default)
        {
            ///////////////////////////
            // Add execution logic HERE
            ///////////////////////////
            string in_training_dataset = this.In_Training_DataSet.Get((ActivityContext)context);
            string in_test_dataset = this.In_Test_Dataset.Get((ActivityContext)context);
            int in_classification_cluster_number = this.In_Classification_Cluster_Number.Get((ActivityContext)context);
            
            K_NEAREST_NEIGHBORS.KNN knn = new K_NEAREST_NEIGHBORS.KNN();
            knn.LoadData(in_training_dataset, KNN.DataType.TRAININGDATA);
            knn.LoadData(in_test_dataset, K_NEAREST_NEIGHBORS.KNN.DataType.TESTDATA);
            var outdt = knn.Classify(in_classification_cluster_number);
            return outdt;
        }
        private class KNN
        {
            private List<double[]> trainingSetValues = new List<double[]>();
            private List<string> trainingSetClasses = new List<string>();
            private List<double[]> testSetValues = new List<double[]>();
            private List<string> testSetClasses = new List<string>();
            private int lines;
            private int K;

            public void LoadData(string path, K_NEAREST_NEIGHBORS.KNN.DataType dataType)
            {
                StreamReader streamReader = new StreamReader(path);
                this.lines = 0;
                Console.WriteLine("[i] reading data from {0} ...", (object)path);
                string str1;
                while ((str1 = streamReader.ReadLine()) != null)
                {
                    string[] array = ((IEnumerable<string>)str1.Split(',')).ToArray<string>();
                    List<string> source = new List<string>(array.Length);
                    source.AddRange((IEnumerable<string>)array);
                    double[] numArray = new double[source.Count - 1];
                    string str2 = source.ElementAt<string>(source.Count - 1);
                    for (int index = 0; index < source.Count - 1; ++index)
                    {
                        double num = double.Parse(source.ElementAt<string>(index));
                        numArray[index] = num;
                    }
                    switch (dataType)
                    {
                        case K_NEAREST_NEIGHBORS.KNN.DataType.TRAININGDATA:
                            this.trainingSetValues.Add(numArray);
                            this.trainingSetClasses.Add(str2);
                            break;
                        case K_NEAREST_NEIGHBORS.KNN.DataType.TESTDATA:
                            this.testSetValues.Add(numArray);
                            this.testSetClasses.Add(str2);
                            break;
                    }
                    ++this.lines;
                }
                Console.WriteLine("[+] done. read {0} lines.", (object)this.lines);
                streamReader.Close();
            }

            public Tuple<DataTable, double> Classify(int neighborsNumber)
            {
                this.K = neighborsNumber;
                
                //Define Datatable
                DataTable dataTable = new DataTable("Output");
                DataColumn dtColumn;
                DataRow myDataRow;
                // Create id column  
                dtColumn = new DataColumn();
                dtColumn.DataType = typeof(String);
                dtColumn.ColumnName = "Output";
                dtColumn.Caption = "Output";
                // Add column to the DataColumnCollection.  
                dataTable.Columns.Add(dtColumn);
                string strtemp = "";
                double[][] distances = new double[this.trainingSetValues.Count][];
                double num1 = 0.0;
                double num2 = 0.0;
                for (int index = 0; index < this.trainingSetValues.Count; ++index)
                    distances[index] = new double[2];
                Console.WriteLine("[i] classifying...");
                for (int test = 0; test < this.testSetValues.Count; test++)
                {
                    Parallel.For(0, this.trainingSetValues.Count, (Action<int>)(index =>
                    {
                        double num3 = K_NEAREST_NEIGHBORS.KNN.EuclideanDistance(this.testSetValues[test], this.trainingSetValues[index]);
                        distances[index][0] = num3;
                        distances[index][1] = (double)index;
                    }));
                    Console.WriteLine("[+] closest K={0} neighbors: ", (object)this.K);
                  
                    ParallelQuery<double[]> parallelQuery = ((IEnumerable<double[]>)distances).AsParallel<double[]>().OrderBy<double[], double>((Func<double[], double>)(t => t[0])).Take<double[]>(this.K);
                    string testSetClass = this.testSetClasses[test];
                    foreach (double[] numArray in parallelQuery)
                    {
                        string trainingSetClass = this.trainingSetClasses[(int)numArray[1]];
                        if (string.Equals(testSetClass, trainingSetClass))
                            ++num1;
                        ++num2;
                        Console.WriteLine("[>>>] test {0}: real class: {1} predicted class: {2}", (object)test, (object)testSetClass, (object)trainingSetClass);
                        strtemp = strtemp + ("[>>>] test " + (object)test + ": real class: " + (object)testSetClass + " predicted class: " + (object)trainingSetClass) + Environment.NewLine;
                    }
                    myDataRow = dataTable.NewRow();
                    myDataRow[dtColumn] = strtemp;
                    dataTable.Rows.Add(myDataRow);
                    //dataTable.Rows.Add(strtemp.ToString());
                    strtemp = "";
                }
                Console.WriteLine();
                Console.WriteLine("[i] accuracy: {0}%", (object)(num1 / num2 * 100.0));
                return new Tuple<DataTable, double>(dataTable, (num1 / num2 * 100.0));
            }

            private static double EuclideanDistance(double[] sampleOne, double[] sampleTwo)
            {
                double d = 0.0;
                for (int index = 0; index < sampleOne.Length; ++index)
                {
                    double num = sampleOne[index] - sampleTwo[index];
                    d += num * num;
                }
                return Math.Sqrt(d);
            }

            public enum DataType
            {
                TRAININGDATA,
                TESTDATA,
            }
        }

        #endregion
    }
}

