namespace Soprasteria.Machine_Learning_Nugets.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for Linear_RegressionDesigner.xaml
    /// </summary>
    public partial class Linear_RegressionDesigner
    {
        public Linear_RegressionDesigner()
        {
            InitializeComponent();
        }
    }
}
