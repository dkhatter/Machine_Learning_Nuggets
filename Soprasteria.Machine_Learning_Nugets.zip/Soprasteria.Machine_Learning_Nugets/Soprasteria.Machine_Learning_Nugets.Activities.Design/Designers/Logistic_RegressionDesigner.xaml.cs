namespace Soprasteria.Machine_Learning_Nugets.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for Logistic_RegressionDesigner.xaml
    /// </summary>
    public partial class Logistic_RegressionDesigner
    {
        public Logistic_RegressionDesigner()
        {
            InitializeComponent();
        }
    }
}
