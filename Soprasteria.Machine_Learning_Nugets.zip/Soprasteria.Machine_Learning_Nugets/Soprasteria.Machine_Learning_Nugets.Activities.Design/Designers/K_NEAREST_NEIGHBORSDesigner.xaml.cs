namespace Soprasteria.Machine_Learning_Nugets.Activities.Design.Designers
{
    /// <summary>
    /// Interaction logic for K_NEAREST_NEIGHBORSDesigner.xaml
    /// </summary>
    public partial class K_NEAREST_NEIGHBORSDesigner
    {
        public K_NEAREST_NEIGHBORSDesigner()
        {
            InitializeComponent();
        }
    }
}
