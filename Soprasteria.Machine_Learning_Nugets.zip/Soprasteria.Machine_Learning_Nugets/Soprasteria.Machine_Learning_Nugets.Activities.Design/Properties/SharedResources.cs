﻿namespace UiPath.Shared.Localization
{
    class SharedResources : Soprasteria.Machine_Learning_Nugets.Activities.Design.Properties.Resources
    {
    }
}