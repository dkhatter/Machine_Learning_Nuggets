using System.Activities.Presentation.Metadata;
using System.ComponentModel;
using System.ComponentModel.Design;
using Soprasteria.Machine_Learning_Nugets.Activities.Design.Designers;
using Soprasteria.Machine_Learning_Nugets.Activities.Design.Properties;

namespace Soprasteria.Machine_Learning_Nugets.Activities.Design
{
    public class DesignerMetadata : IRegisterMetadata
    {
        public void Register()
        {
            var builder = new AttributeTableBuilder();
            builder.ValidateTable();

            var categoryAttribute = new CategoryAttribute($"{Resources.Category}");

            builder.AddCustomAttributes(typeof(Logistic_Regression), categoryAttribute);
            builder.AddCustomAttributes(typeof(Logistic_Regression), new DesignerAttribute(typeof(Logistic_RegressionDesigner)));
            builder.AddCustomAttributes(typeof(Logistic_Regression), new HelpKeywordAttribute(""));

            builder.AddCustomAttributes(typeof(Linear_Regression), categoryAttribute);
            builder.AddCustomAttributes(typeof(Linear_Regression), new DesignerAttribute(typeof(Linear_RegressionDesigner)));
            builder.AddCustomAttributes(typeof(Linear_Regression), new HelpKeywordAttribute(""));

            builder.AddCustomAttributes(typeof(K_NEAREST_NEIGHBORS), categoryAttribute);
            builder.AddCustomAttributes(typeof(K_NEAREST_NEIGHBORS), new DesignerAttribute(typeof(K_NEAREST_NEIGHBORSDesigner)));
            builder.AddCustomAttributes(typeof(K_NEAREST_NEIGHBORS), new HelpKeywordAttribute(""));


            MetadataStore.AddAttributeTable(builder.CreateTable());
        }
    }
}
