﻿namespace UiPath.Shared.Localization
{
    class SharedResources : Soprasteria.Machine_Learning_Nugets.Properties.Resources
    {
    }
}